var searchData=
[
  ['confidence',['confidence',['../class_adafruit___fingerprint.html#aa0a2aecc94edcce3d4717b51e22114e1',1,'Adafruit_Fingerprint']]],
  ['createmodel',['createModel',['../class_adafruit___fingerprint.html#a79d36eb63d36c60ab43198ac47120f76',1,'Adafruit_Fingerprint']]]
];
