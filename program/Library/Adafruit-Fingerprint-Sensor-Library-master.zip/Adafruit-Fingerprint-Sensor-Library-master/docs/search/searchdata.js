var indexSectionsWithContent =
{
  0: "abcdefgilstvw",
  1: "a",
  2: "abcdefgilsvw",
  3: "cft"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

